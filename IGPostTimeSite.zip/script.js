
function generateTime() {
    const timezone = document.getElementById('timezone').value;
    const result = document.getElementById('result');

    if (!timezone) {
        result.innerHTML = "<p>Please select a timezone!</p>";
        return;
    }

    let bestTimes = {
        "Asia/Kolkata": "7:00 PM – 9:00 PM IST",
        "America/New_York": "6:00 PM – 8:00 PM EST",
        "Europe/London": "5:00 PM – 7:00 PM GMT"
    };

    result.innerHTML = "<h2>📅 Best Time to Post:</h2><p>" + bestTimes[timezone] + "</p>";
}
